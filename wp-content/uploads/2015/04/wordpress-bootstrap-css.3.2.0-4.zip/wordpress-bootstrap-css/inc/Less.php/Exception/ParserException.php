<?php


class Less_ParserException extends Exception{

}